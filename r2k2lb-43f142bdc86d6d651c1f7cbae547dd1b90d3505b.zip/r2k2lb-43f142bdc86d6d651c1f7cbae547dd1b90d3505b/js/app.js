document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".logo-title").addEventListener("click", function () {
        window.location.href = "/";
    });
});
